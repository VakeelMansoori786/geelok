const dbexec = {}

export default dbexec